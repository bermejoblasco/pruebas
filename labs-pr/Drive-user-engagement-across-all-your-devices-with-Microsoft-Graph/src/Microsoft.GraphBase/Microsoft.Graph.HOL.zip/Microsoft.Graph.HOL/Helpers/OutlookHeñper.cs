﻿namespace Microsoft.Graph.HOL
{
    using System;
    using System.Diagnostics;
    using System.Threading.Tasks;

    public class OutlookHeñper
    {
        public static async Task<IUserContactsCollectionPage> GetContacts()
        {
            throw new NotImplementedException();          
        }

        public static async Task SetAppintment(string subject, DateTime startCombo, DateTime endCombo)
        {
            throw new NotImplementedException();
        }
    }
}
